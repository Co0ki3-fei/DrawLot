function r(e,l){let n=[];for(let t=0;t<e.length;t+=l)n.push(e.slice(t,t+l));return n}export{r as c};
